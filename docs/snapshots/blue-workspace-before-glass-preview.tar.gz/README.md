# EmpireProject — prototype redesign

English/LTR and dark blue glass are now the defaults. Persian/RTL and a light theme remain available. This is a local, deterministic prototype, awaiting visual and interaction review. No backend, account connection or live AI is used.

## Run

Requires Node.js 22.17+ and npm. From the repository directory:

```sh
npm ci
npm run dev
```

Open http://127.0.0.1:5173. The development server binds to localhost.

```sh
npm run typecheck
npm test
npm run build
npm run test:e2e
```

Browser tests use installed Google Chrome (`channel: 'chrome'`). No bundled Playwright browser is required when Chrome is installed.

## Three review journeys

The persistent command composer accepts these prompts. The Demo assistant also provides clickable entry points.

1. **Show remaining work** → six remaining issues in the main workspace. **Only blocked** → EMP-103 and EMP-104. List, Board and Timeline retain the same result set. Grouping, sorting and search remain available manually.
2. **Why is delivery at risk?** → a main-workspace investigation with the two blocked issues, the recorded EMP-103 → EMP-104 dependency, owners, documented blockers and EMP-104's missing dates. Facts and suggested interpretation are separate. Inspect either issue or choose **Draft next step**.
3. **Help me unblock this** → first inspect an issue, then close the drawer and issue the command, or use the drawer's matching action. The selected issue's evidence, dependencies, acceptance criteria and proposed action appear beside an editable follow-up draft. Edits are stored locally; **Save draft** explicitly saves/retries. No message is sent and issue status is unchanged.

**Back** restores the preceding workspace. Closing a drawer keeps its issue selected as composer context. **Ctrl/Cmd+K** focuses the composer. Unsupported prompts receive an explicit fallback without changing data.

Other commands: `Group by assignee`, `Show timeline`, `Open EMP-104`, `Show all issues`, `Explain only`.

Persian equivalents for the three journeys: `ایشوهای مانده این اسپرینت را نشان بده`, `چرا تحویل در خطر است؟`, `کمک کن این مانع را رفع کنم`.

## Local behavior

- Existing issue data and edits retain the `empire-demo-v2` storage key. Missing English fixture fields are supplemented on load; issue edits are preserved.
- Follow-up drafts use `empire-follow-up-drafts-v1`, keyed by immutable issue ID.
- Reset issue data resets the synthetic issues, with one-level Undo. It preserves separately saved follow-up drafts.
- Language switching translates interface and fixture content. User-authored issue text and edited drafts remain exactly as written.
- Demo scenarios expose loading, empty and error/retry states.
- Dense tables scroll internally, and horizontally on smaller screens. The assistant stacks beneath the workspace on narrow screens.

## Implementation boundaries

- `src/domain.ts`: typed issue/query model, bounded `work | risk | unblock` compositions and navigation history.
- `src/intent.ts`: deterministic intent parsing and stale-response protection.
- `src/repository.ts`: local issue persistence and query adapter.
- `src/Views.tsx`: List, Board and Timeline registry.
- `src/Investigation.tsx`: recorded delivery evidence and separately labeled suggestion.
- `src/Unblock.tsx`, `src/drafts.ts`: selected-issue follow-up and local persistence.
- `src/App.tsx`, `src/Modal.tsx`, `src/styles.css`: redesigned shell, interactions, keyboard dialog and visual system.
- `fixtures/sprint12.json`: bilingual canonical synthetic dataset, still 12 total / 6 remaining / 2 blocked.

[Implementation and review report](docs/IMPLEMENTATION_REPORT.md) · [Actual screenshots](docs/screenshots/redesign/)

Status: **awaiting_visual_and_interaction_review**. No Stage 2 work is authorized or implemented.
