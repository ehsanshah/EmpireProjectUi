# Prototype redesign — implementation report

Date: 2026-10-22

Previous prototype: rejected by user. This revision remains in the prototype phase.

Gate status: `awaiting_prototype_review`
Delivery status: `awaiting_visual_and_interaction_review`

No user approval is recorded. No backend, deployment, external service connection or additional product module was implemented.

## What changed

The pale composition was replaced with a navy workspace, restrained cobalt/cyan background illumination, inset translucent navigation, layered assistant and command surfaces, visible edge highlights and backdrop blur. Dense issue surfaces remain opaque. The assistant is a contextual side panel with three explicit journey entry points, and the persistent composer shows sprint scope, current composition, result count and selected issue.

English/LTR, dark theme and Gregorian dates are defaults. Persian/RTL, Persian dates and light theme remain selectable. Navigation, fixture titles/descriptions, acceptance criteria, blocker reasons, sample conversations, accessible controls, empty/error states and assistant responses have English and Persian variants. User-authored content and edited drafts are preserved in their source language.

Working query evaluation, local issue editing, creation, Undo, reset, shared renderer result sets, date-only handling and stale-command protection were retained. Existing persisted issue data uses the same storage key, with missing English fixture fields supplemented without discarding edits.

## Completed journeys

1. **Show remaining work → Only blocked** changes the main workspace from 6 to 2 records. List/Board/Timeline retain EMP-103 and EMP-104. Filters can be inspected and changed manually.
2. **Why is delivery at risk?** opens a typed investigation composition. It shows the actual EMP-103 → EMP-104 dependency, Sara/Reza ownership, recorded blocker reasons and missing start/due dates for EMP-104. Suggested interpretation is explicitly labeled. No risk scores, delivery forecasts, invented causes or dates are generated. Each issue has Inspect and Draft next step actions.
3. **Help me unblock this** uses the selected issue. Dependency direction, relevant acceptance criteria and a proposed action are presented beside an editable local follow-up draft. Changes persist by issue ID and survive reload. Save feedback distinguishes a local save from sending; storage failure is reported honestly. No issue status changes or external messages occur.

History stores the bounded `work | risk | unblock` composition as well as filters, grouping, sort and view. Closing details retains the selected issue for the next command. Back restores prior workspace state. Missing issue context and unsupported prompts produce explicit fallbacks.

## Visual review sequence

The English desktop workspace and delivery investigation were implemented and captured first. Actual Chrome screenshots were inspected before building the follow-up editor.

Corrections from inspection:

- Reduced the investigation's vertical footprint so both blockers, their actions, the dependency and scheduling information are visible together at 1440×900.
- Increased issue and assistant-entry typography.
- Kept fact and suggested-interpretation labels distinct.
- Gave the selected-issue composition its own evidence/editor layout instead of leaving table controls above it; the complete desktop draft editor and context now fit together.
- Checked actual English dark, Persian RTL, optional light and 390/768px captures. Tables deliberately scroll horizontally on narrow screens; the page itself does not overflow.

## Verification

- `npm run typecheck`: passed.
- `npm test`: 13 tests passed (10 query/intent/history/composition tests, 3 local-draft tests).
- `npm run build`: passed.
- `npm run test:e2e`: 5 Chrome tests passed. Covers the three journeys, 12/6/2 counts, unchanged result sets, history and selected context, focus restoration, English fixture details, draft edit/save/reload, no status mutation, unsupported prompts, missing context, issue edit/Undo/reload, create/reset, error/retry/empty states, Ctrl+K, Persian RTL, optional light theme and 390/768px widths.
- Eight complete issue rows and the composer are asserted within the visible desktop data surface.
- The full investigation-to-draft browser journey records network requests and asserts no external requests.
- Storage tests cover unavailable/corrupt draft storage and ensure it is never reported as saved.

Browser verification was available using installed Chrome. No Safari/Firefox, screen-reader, production-scale or enterprise security audit is claimed.

## Actual screenshots

- [English desktop workspace](screenshots/redesign/01-workspace.png)
- [Delivery-risk investigation](screenshots/redesign/02-risk-investigation.png)
- [Edited local follow-up draft](screenshots/redesign/03-unblock-draft.png)
- [Shared-query timeline](screenshots/redesign/04-timeline.png)
- [390px workspace](screenshots/redesign/06-width-390.png)
- [768px workspace](screenshots/redesign/06-width-768.png)
- [Persian RTL investigation](screenshots/redesign/07-persian-risk.png)
- [Optional light investigation](screenshots/redesign/08-light-risk.png)

These are real browser captures. Screenshots in the parent screenshots directory belong to the rejected earlier prototype.

## Limitations and handoff

The assistant is deterministic and supports the documented journeys and examples, not unrestricted language. No LLM or backend is connected. Drafts are stored in this browser only; resetting issue data preserves separately saved drafts. There is no recipient, external send, scheduled follow-up, date editor, advanced planning engine or risk prediction. Local storage and browser filters are not an authorization boundary.

Setup and exact review steps are in `README.md`. The local preview is http://127.0.0.1:5173. Passing checks is not visual approval. Stop here for the user's visual and interaction review.
