import {seed,evaluate,type Issue,type UIState} from './domain';
const KEY='empire-demo-v2';
export class IssueRepository {
 query(issues:Issue[],query:UIState){return evaluate(issues,query)}
 load():{issues:Issue[];error:boolean}{try{const raw=localStorage.getItem(KEY);if(!raw)return {issues:seed(),error:false};const data=JSON.parse(raw);if(!Array.isArray(data)||!data.every(i=>typeof i.id==='string'&&typeof i.title==='string'&&Array.isArray(i.dependencies)&&['todo','in_progress','review','completed','cancelled'].includes(i.status)))throw Error('Invalid demo');return {issues:data.map(i=>{const original=seed().find(s=>s.id===i.id);return {...original,...i,descriptionEn:i.descriptionEn??original?.descriptionEn??i.description,acceptanceCriteriaEn:i.acceptanceCriteriaEn??original?.acceptanceCriteriaEn??i.acceptanceCriteria,blockerReasonEn:i.blockerReasonEn??original?.blockerReasonEn??i.blockerReason,comments:i.comments.map((c:Record<string,string>,n:number)=>({...original?.comments[n],...c}))}}),error:false};}catch{return {issues:seed(),error:true}}}
 save(issues:Issue[]){try{localStorage.setItem(KEY,JSON.stringify(issues));return true}catch{return false}}
}
