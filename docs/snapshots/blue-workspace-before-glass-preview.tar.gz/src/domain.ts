import fixture from '../fixtures/sprint12.json';
export type Status = 'todo'|'in_progress'|'review'|'completed'|'cancelled';
export type Issue = Omit<typeof fixture.issues[number],'status'|'dependencies'> & {status:Status;dependencies:string[]};
export type Composition = 'work'|'risk'|'unblock';
export type View = 'list'|'board'|'timeline';
export interface UIState {composition:Composition;contextIssueId:string|null;projectId:string;sprintId:string;filter:{remaining?:boolean;blocked?:boolean;search?:string};sort:'key'|'priority'|'due';groupBy:'none'|'assignee';view:View;selectedIssueId:string|null;revision:number}
export const initialState:UIState={composition:'work',contextIssueId:null,projectId:'empire',sprintId:'sprint-12',filter:{},sort:'key',groupBy:'none',view:'list',selectedIssueId:null,revision:0};
export type UIIntent = {type:'investigateRisk'}|{type:'helpUnblock';id:string|null}| {type:'showIssues';remaining:boolean}|{type:'refineFilter';blocked:boolean}|{type:'groupBy';value:UIState['groupBy']}|{type:'switchView';view:View}|{type:'openIssue';id:string}|{type:'goBack'}|{type:'explain'}|{type:'unsupported'}|{type:'patch';value:Partial<UIState>};
export const seed=()=>structuredClone(fixture.issues) as Issue[];
export const users=fixture.users;
export const remaining=(i:Issue)=>!['completed','cancelled'].includes(i.status);
export function evaluate(issues:Issue[],q:UIState){return issues.filter(i=>i.projectId===q.projectId&&i.sprintId===q.sprintId&&(!q.filter.remaining||remaining(i))&&(!q.filter.blocked||i.blocked)&&(!q.filter.search||`${i.title} ${i.titleEn} ${i.semanticKey}`.toLowerCase().includes(q.filter.search.toLowerCase()))).sort((a,b)=>q.sort==='priority'?Number(b.priority==='high')-Number(a.priority==='high'):q.sort==='due'?(a.dueDate??'9999').localeCompare(b.dueDate??'9999'):a.semanticKey.localeCompare(b.semanticKey));}
export interface Navigation {current:UIState;history:UIState[]}
export function navigate(nav:Navigation,intent:UIIntent):Navigation{
 const s=nav.current;
 if(intent.type==='explain'||intent.type==='unsupported')return nav;
 if(intent.type==='goBack')return nav.history.length?{current:{...nav.history.at(-1)!,...(s.selectedIssueId?{contextIssueId:s.contextIssueId}:{}),revision:s.revision+1},history:nav.history.slice(0,-1)}:nav;
 let next:UIState={...s,revision:s.revision+1};
 switch(intent.type){case 'investigateRisk':next={...next,composition:'risk',filter:{remaining:true,blocked:true},selectedIssueId:null,contextIssueId:null};break;case 'helpUnblock':if(!intent.id)return nav;next={...next,composition:'unblock',contextIssueId:intent.id,selectedIssueId:null};break;case 'showIssues':next={...next,composition:'work',contextIssueId:null,filter:intent.remaining?{remaining:true}:{},view:'list',selectedIssueId:null};break;case 'refineFilter':next.filter={...s.filter,blocked:intent.blocked};break;case 'groupBy':next.groupBy=intent.value;break;case 'switchView':next.view=intent.view;next.composition='work';break;case 'openIssue':next.selectedIssueId=intent.id;next.contextIssueId=intent.id;break;case 'patch':next={...next,...intent.value};}
 return {current:next,history:[...nav.history,s]};
}
export function dateLabel(date:string|null,locale:string,calendar:string){return date?new Intl.DateTimeFormat(locale,{calendar,month:'short',day:'numeric',timeZone:'UTC'}).format(new Date(date+'T12:00:00Z')):'—';}
